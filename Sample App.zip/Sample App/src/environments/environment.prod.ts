export const environment = {
  production: true,
  serviceEndPoint: 'http://jsonplaceholder.typicode.com/users'
};
